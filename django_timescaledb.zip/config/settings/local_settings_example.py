MAX_RETRIES = 3
SPLAY_HOST = ""
SPLAY_STAT_SECRET_KEY = ""

CELERY_BROKER_URL = "redis://localhost:6379"
CELERY_RESULT_BACKEND = "redis://localhost:6379"
