MAX_RETRIES = 3
SPLAY_HOST = "https://api.splay.uz"
SPLAY_STAT_SECRET_KEY = "7d-_=#@xqoxtr"

CELERY_BROKER_URL = "redis://localhost:6379"
CELERY_RESULT_BACKEND = "redis://localhost:6379"
