SECRET_KEY = "django-insecure-%6ft#6s_w+_b$lh#c!9ec56h8o#!)!*dyyc08e!-1192sq9g%h"
DEBUG = True
ALLOWED_HOSTS = ["*"]

MAX_RETRIES = 3
SPLAY_HOST = "https://api.splay.uz"
SPLAY_STAT_SECRET_KEY = "7d-_=#@xqoxtr"

CELERY_BROKER_URL = "redis://localhost:6379"
CELERY_RESULT_BACKEND = "redis://localhost:6379"
